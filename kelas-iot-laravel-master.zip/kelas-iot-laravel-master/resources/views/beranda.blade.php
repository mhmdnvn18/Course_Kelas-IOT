<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Beranda</title>
</head>
<body>
    <h1>Beranda</h1>
    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Voluptatum eveniet eius officiis consectetur accusamus voluptates ullam saepe quisquam! Ipsam, quisquam consequuntur. Porro quasi facilis debitis ratione nam nihil temporibus ab.</p>
</body>
</html>
